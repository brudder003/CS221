tetris
======

a tetris clone written in python

dependencies
------------

* pyglet - http://www.pyglet.org/
